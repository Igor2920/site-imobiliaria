import Image from 'next/image';
import Link from 'next/link';
import {
  FaBed,
  FaBath,
  FaRulerCombined,
  FaMoneyBill,
  FaMapMarker,
} from 'react-icons/fa';

// Calcula e formata a taxa mais relevante para exibição no card de destaque
const getRateDisplay = (rates) => {
  const { nightly, weekly, monthly } = rates;

  if (monthly) {
    return `R$ ${monthly.toLocaleString('pt-BR')}/mês`;
  } else if (weekly) {
    return `R$ ${weekly.toLocaleString('pt-BR')}/semana`;
  } else if (nightly) {
    return `R$ ${nightly.toLocaleString('pt-BR')}/noite`;
  }
};

// Card de imóvel em destaque — versão horizontal com imagem maior
const FeaturedPropertyCard = ({ property }) => {
  return (
    <div className='bg-white rounded-xl shadow-md relative flex flex-col md:flex-row'>
      {/* Imagem do imóvel */}
      <Image
        src={property.images[0]}
        alt={property.name}
        width={0}
        height={0}
        sizes='100vw'
        className='object-cover rounded-t-xl md:rounded-tr-none md:rounded-l-xl w-full md:w-2/5'
      />

      {/* Informações do imóvel */}
      <div className='p-6'>
        <h3 className='text-xl font-bold'>{property.name}</h3>
        <div className='text-gray-600 mb-4'>{property.type}</div>

        <h3 className='absolute top-[10px] left-[10px] bg-white px-4 py-2 rounded-lg text-blue-500 font-bold text-right md:text-center lg:text-right'>
          {getRateDisplay(property.rates)}
        </h3>

        {/* Detalhes do imóvel */}
        <div className='flex justify-center gap-4 text-gray-500 mb-4 text-sm'>
          <p>
            <FaBed className='inline-block mr-2' />
            {property.beds}{' '}
            <span className='md:hidden lg:inline'>Quartos</span>
          </p>
          <p>
            <FaBath className='inline-block mr-2' />
            {property.baths}{' '}
            <span className='md:hidden lg:inline'>Banheiros</span>
          </p>
          <p>
            <FaRulerCombined className='inline-block mr-2' />
            {property.square_feet}{' '}
            <span className='md:hidden lg:inline'>m²</span>
          </p>
        </div>

        {/* Taxa de aluguel */}
        <div className='flex justify-center gap-4 text-green-900 text-sm mb-4'>
          {property.rates.nightly && (
            <p>
              <FaMoneyBill className='inline-block mr-2' />
              R$ {property.rates.nightly.toLocaleString('pt-BR')}/noite
            </p>
          )}
          {property.rates.weekly && (
            <p>
              <FaMoneyBill className='inline-block mr-2' />
              R$ {property.rates.weekly.toLocaleString('pt-BR')}/semana
            </p>
          )}
          {property.rates.monthly && (
            <p>
              <FaMoneyBill className='inline-block mr-2' />
              R$ {property.rates.monthly.toLocaleString('pt-BR')}/mês
            </p>
          )}
        </div>

        {/* Localização */}
        <div className='border border-gray-100 mb-5'></div>
        <div className='flex flex-col lg:flex-row justify-between'>
          <div className='flex align-middle gap-2 mb-4 lg:mb-0'>
            <FaMapMarker className='text-orange-700 mt-1' />
            <span className='text-orange-700'>
              {property.location.city}, {property.location.state}
            </span>
          </div>

          <Link
            href={`/properties/${property._id}`}
            className='h-[36px] bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-center text-sm'
          >
            Ver Detalhes
          </Link>
        </div>
      </div>
    </div>
  );
};

export default FeaturedPropertyCard;
