import connectDB from '@/config/database';
import Property from '@/models/Property';
import { getSessionUser } from '@/utils/getSessionUser';
import { convertToSerializableObject } from '@/utils/convertToObject';
import Image from 'next/image';
import ProfileProperties from '@/components/ProfileProperties';
import { toast } from 'react-toastify';

// Página de perfil do usuário — lista os imóveis cadastrados pelo usuário logado
const ProfilePage = async () => {
  await connectDB();

  const sessionUser = await getSessionUser();

  const { userId } = sessionUser;

  // Busca todos os imóveis cadastrados pelo usuário
  const propertiesDocs = await Property.find({ owner: userId }).lean();
  const properties = propertiesDocs.map(convertToSerializableObject);

  return (
    <section className='bg-blue-50'>
      <div className='container m-auto py-24'>
        <div className='bg-white px-6 py-8 mb-4 shadow-md rounded-md border m-4 md:m-0'>
          <h1 className='text-3xl font-bold mb-4'>Meu Perfil</h1>
          <div className='flex flex-col md:flex-row'>
            {/* Coluna esquerda: avatar e informações do usuário */}
            <div className='md:w-1/4 mx-20 mt-10'>
              <div className='mb-4'>
                <Image
                  className='h-32 w-32 md:h-48 md:w-48 rounded-full mx-auto md:mx-0'
                  src={sessionUser.user.image}
                  width={200}
                  height={200}
                  alt='Foto de perfil do usuário'
                />
              </div>
              <h2 className='text-2xl mb-4'>
                <span className='font-bold block'>Nome: </span>
                {sessionUser.user.name}
              </h2>
              <h2 className='text-2xl'>
                <span className='font-bold block'>E-mail: </span>
                {sessionUser.user.email}
              </h2>
            </div>

            {/* Coluna direita: listagem dos imóveis do usuário */}
            <div className='md:w-3/4 md:pl-4'>
              <h2 className='text-xl font-semibold mb-4'>Meus Imóveis</h2>
              <ProfileProperties properties={properties} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProfilePage;
