import Link from 'next/link';
import { FaExclamationTriangle } from 'react-icons/fa';

// Página 404 — exibida quando uma rota não é encontrada
const NotFoundPage = () => {
  return (
    <section className='bg-blue-50 min-h-screen flex-grow'>
      <div className='container m-auto max-w-2xl py-24'>
        <div className='bg-white px-6 py-24 mb-4 shadow-md rounded-md border m-4 md:m-0'>
          <div className='flex justify-center'>
            <FaExclamationTriangle className='text-8xl text-yellow-400' />
          </div>
          <div className='text-center'>
            <h1 className='text-3xl font-bold mt-4 mb-2'>Página Não Encontrada</h1>
            <p className='text-gray-500 text-xl mb-10'>
              A página que você está procurando não existe.
            </p>
            <Link
              href='/'
              className='bg-blue-700 hover:bg-blue-800 text-white font-bold py-4 px-6 rounded'
            >
              Voltar para o Início
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NotFoundPage;
