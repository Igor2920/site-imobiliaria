'use server';

import connectDB from '@/config/database';
import Property from '@/models/Property';
import { getSessionUser } from '@/utils/getSessionUser';
import { revalidatePath } from 'next/cache';
import cloudinary from '@/config/cloudinary';

// Server Action — exclui um imóvel e suas imagens do Cloudinary
async function deleteProperty(propertyId) {
  await connectDB();

  const sessionUser = await getSessionUser();

  if (!sessionUser || !sessionUser.userId) {
    throw new Error('Você precisa estar logado para excluir um imóvel.');
  }

  const { userId } = sessionUser;

  const property = await Property.findById(propertyId);

  if (!property) throw new Error('Imóvel não encontrado.');

  // Somente o proprietário pode excluir o imóvel
  if (property.owner.toString() !== userId) {
    throw new Error('Você não tem permissão para excluir este imóvel.');
  }

  // Remove cada imagem do Cloudinary usando o public_id extraído da URL
  const publicIds = property.images.map((imageUrl) => {
    const parts = imageUrl.split('/');
    return `${parts.at(-2)}/${parts.at(-1).split('.').at(0)}`;
  });

  if (publicIds.length > 0) {
    for (const publicId of publicIds) {
      await cloudinary.uploader.destroy(publicId);
    }
  }

  await property.deleteOne();

  revalidatePath('/', 'layout');
}

export default deleteProperty;
