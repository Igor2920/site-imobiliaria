import { getServerSession } from 'next-auth/next';
import { authOptions } from './authOptions';

// Utilitário — retorna o usuário da sessão atual no servidor
export const getSessionUser = async () => {
  const session = await getServerSession(authOptions);

  if (!session || !session.user) {
    return null;
  }

  return {
    user: session.user,
    userId: session.user.id,
  };
};
